

public interface Protocal {
	int SLOGIN=1001;
	int TLOGIN=1002;
	int ADDCOURSE=1002;
}
