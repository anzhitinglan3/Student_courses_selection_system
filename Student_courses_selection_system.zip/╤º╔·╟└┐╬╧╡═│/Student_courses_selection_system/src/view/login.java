package view;
import java.awt.*;
import javax.swing.*;


public class login extends JFrame{
	JLabel title = new JLabel("����ϵͳ���Ӳ�������       ");
	JLabel name = new JLabel("�û�����");
	JLabel password = new JLabel("��  �룺");
	JTextField stufield= new JTextField(8);
	JPasswordField passfield= new JPasswordField(8);
	JRadioButton stubutton= new JRadioButton("ѧ��");
	JRadioButton admbutton= new JRadioButton("��ʦ");
	ButtonGroup bg=new ButtonGroup();
	JButton loginbutton= new JButton("��¼");
	JButton cancelbutton= new JButton("ȡ��");
	public login(){
		this.setTitle("ѧ������ϵͳ");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(220,240);
		this.setLayout(new FlowLayout());
		this.setResizable(false);
		add(title);
		add(name);
		add(stufield);
		add(password);
		add(passfield);
		add(stubutton);
		add(admbutton);
		bg.add(stubutton);
		bg.add(admbutton);
		add(loginbutton);
		add(cancelbutton);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}
	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper
					.launchBeautyEyeLNF();
			new login();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
