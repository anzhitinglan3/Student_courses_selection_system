package view;

import java.awt.*;
import javax.swing.*;


public class TCourseM extends JFrame{
	JLabel title = new JLabel("��ӭ����ʦ������ ");
	JButton addbutton= new JButton("���ӿγ�");
	JButton deletebutton= new JButton("ɾ���γ�");
	JButton seekbutton= new JButton("���ҿγ�");
	JButton updatabutton= new JButton("�޸Ŀγ�");
	public TCourseM(){
		this.setTitle("��ʦ�γ̹���");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(220,200);
		this.setLayout(new FlowLayout());
		this.setResizable(false);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		add(title);
		add(addbutton);
		add(deletebutton);
		add(seekbutton);
		add(updatabutton);
	}
	public static void main(String[] args) {
		
		try{
			org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper.launchBeautyEyeLNF();
			new TCourseM();
			}catch(Exception e){
				e.printStackTrace();
			}
	}
}
