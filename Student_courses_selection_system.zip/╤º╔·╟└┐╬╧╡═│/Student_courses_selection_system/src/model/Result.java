package model;

public class Result {
	private int cid;
	private int sid;
	private double score;
	private String status;
	public Result(int cid, int sid, double score, String status) {
		super();
		this.cid = cid;
		this.sid = sid;
		this.score = score;
		this.status = status;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public double getScore() {
		return score;
	}
	public void setScore(double score) {
		this.score = score;
	}
    
}
