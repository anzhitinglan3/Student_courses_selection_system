package model;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Student implements Serializable{
   private static final String cid = null;
   private int sid;
   private String sname;
   private String spw;
   private String sclass;
   private String smajor;
   private int maxcredit=10;
   public Student(int sid, String sname, String spw, String sclass, String smajor) {
	super();
	this.sid = sid;
	this.sname = sname;
	this.spw = spw;
	this.sclass = sclass;
	this.smajor = smajor;
	//this.maxcredit = maxcredit;
}
public String getSclass() {
	return sclass;
}
public void setSclass(String sclass) {
	this.sclass = sclass;
}
public String getSmajor() {
	return smajor;
}
public void setSmajor(String smajor) {
	this.smajor = smajor;
}

   
   public Student(){
	   
   }
public int getSid() {
	return sid;
	}
   public void setSid(int sid) {
	this.sid = sid;
	}
   public String getSname() {
	return sname;
	}
   public void setSname(String sname) {
	this.sname = sname;
	}
   public String getSpw() {
	return spw;
	}
   public void setSpw(String spw) {
	this.spw = spw;
	}
   protected ArrayList<Result> ViewAllResult() throws SQLException, ClassNotFoundException {
	   ArrayList<Result> results=new ArrayList<Result>();
	   String sql="select * from result where sid="+sid;
	   ResultSet rs=DataConnect.getStat().executeQuery(sql);
	   while(rs.next())
		   results.add(new Result(rs.getInt(1),rs.getInt(2),rs.getDouble(3),
				   rs.getString(4)));
	return results;
	// TODO Auto-generated method stub
	   }
   public ArrayList<Course> getCourse() throws SQLException, ClassNotFoundException{
	   ArrayList<Course> courses=new ArrayList<Course>();
	   String sql="select * from course";
	   ResultSet rs=DataConnect.getStat().executeQuery(sql);
	   while(rs.next())
		   courses.add(new Course(rs.getInt(1),rs.getInt(2),rs.getString(3),rs.getString(4),
				   rs.getString(5)));
	return courses;
   }
   protected Result viewCourseResult(int cid) throws SQLException, ClassNotFoundException {
	   Result re=null;
	   String sql="select * from Result where sid="+sid+" and cid="+cid;
	   ResultSet rs=DataConnect.getStat().executeQuery(sql);
	   if(rs.next())
		   re=new Result(rs.getInt(1),rs.getInt(2),rs.getDouble(3),
				   rs.getString(4));
	   return re;
	// TODO Auto-generated method stub

}
   /*
   public Student slogin(int sid,String spw) throws SQLException,ClassNotFoundException{
	   Student stu=null;
	   String sql="select * from student where sid="+sid+" and spw='"+spw+"'";
	   ResultSet rs=DataConnect.getStat().executeQuery(sql);
	   if(rs.next())
		   stu=new Student(sid,rs.getString("sname"),spw);
	   return stu;
   }*/
   private ArrayList<Course> sSearCou(int cid) throws SQLException, ClassNotFoundException{
	   ArrayList<Course> courses=new ArrayList<Course>();
	   String sql="select * from course where cid="+cid;
	   ResultSet rs=DataConnect.getStat().executeQuery(sql);
	   while(rs.next())
		   courses.add(new Course(rs.getInt(1),rs.getInt(2),rs.getString(3),
				   rs.getString(4),rs.getString(5)));
	   return courses;
   }

   private int getCredit() throws SQLException, ClassNotFoundException{
	   int credit=0;
	   ArrayList<Integer> ids=new ArrayList<Integer>();
	   String sql="select cid from result where sid="+sid;
	   ResultSet rs=DataConnect.getStat().executeQuery(sql);
	   while(rs.next())
		   ids.add(rs.getInt(1));
	   for(int i=0;i<ids.size();i++){
		   sql="select credit from course where id="+ids.get(i);
		   rs=DataConnect.getStat().executeQuery(sql);
		   if(rs.next())
			   credit+=rs.getInt(1);
	   }
	   return credit;
   }
   private boolean isCreFull(int credit) throws SQLException, ClassNotFoundException{
	   if(this.getCredit()+credit>maxcredit)
		   return false;
	   return true;
   }
   private boolean isCourFull(int cid) throws Exception{
	   int count=0,max=0;
	   String sql="select count(sid) from result where cid="+cid;
	   ResultSet rs=DataConnect.getStat().executeQuery(sql);
	   if(rs.next())
		   count=rs.getInt(1);
	   sql="select max from course where id="+cid;
	   rs=DataConnect.getStat().executeQuery(sql);
	   if(rs.next())
		   max=rs.getInt(1);
	   if(max<=0) throw new Exception("���ݿ���޿γ�");
	   if(max>count) return true;
	   return false;
   }
   private boolean addCourse(Course course) throws Exception{
	   //if(!this.isCreFull(course.getCredit()))
		//	   return false;
	   if(!this.isCourFull(course.getId()))
		   return false;
	   String sql="insert into course(cid,tid,cname,ctime,clocation) values(?,?,?,?,?)";
	   PreparedStatement pstmt=DataConnect.getCon().prepareStatement(sql);
	   pstmt.setInt(1, course.getId());
	   pstmt.setInt(2, course.getTid());
	   pstmt.setString(3, course.getName());
	   pstmt.setString(4, course.getClasstime());
	   pstmt.setString(5, course.getClocation());
	   //pstmt.setInt(5, course.getCredit());
	   //pstmt.setInt(6, course.getMax());
	   if(pstmt.executeUpdate()==1)
		   return true;
	   return false;
   }
   /*
    * int cid,int tid,String cname, String ctime,
			String clocation
    */
   
   /*
   public ArrayList<Course> getCourse() {
	// TODO Auto-generated method stub
	return null;
	}*/
}
