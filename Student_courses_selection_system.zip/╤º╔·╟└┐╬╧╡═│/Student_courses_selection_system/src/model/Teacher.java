package model;

import java.util.ArrayList;

public class Teacher {
	private int tid;
	private String tname;
	private String tpw;
	public Teacher(int tid,String tname,String tpw){
		super();
		this.tid=tid;
		this.tname=tname;
	    this.tpw=tpw;
	}
	public Teacher() {
		this.tname=tname;
	}
	public int getTid() {
		return tid;
	}
	public void setTid(int tid) {
		this.tid = tid;
	}
	public String getTname() {
		return tname;
	}
	public void setTname(String tname) {
		this.tname = tname;
	}
	public String getTpw() {
		return tpw;
	}
	public void setTpw(String tpw) {
		this.tpw = tpw;
	}
	private void addStudent() {
		// TODO Auto-generated method stub

	}
	public ArrayList<Course> getCourse(int cid) {
		// TODO Auto-generated method stub
		return null;
	}
}
