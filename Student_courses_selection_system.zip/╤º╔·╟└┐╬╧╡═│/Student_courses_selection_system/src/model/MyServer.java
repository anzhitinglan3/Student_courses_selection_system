package model;

import java.io.*;
import java.net.*;


public class MyServer {
	
	private ObjectInputStream ois;
	private ObjectOutputStream oos;
	public MyServer() throws UnknownHostException, IOException, ClassNotFoundException{
		
		int port = 3081;
		ServerSocket ss = new ServerSocket(port);
		System.out.println("������������");
		int count =1;
		while(true){
			Socket s =ss.accept();
			System.out.println("��"+count+"�û����ʣ�ip��ַΪ:"+s.getInetAddress());
			count++;
			ois = new ObjectInputStream(s.getInputStream());
			oos = new ObjectOutputStream(s.getOutputStream());
			int command = ois.readInt();
			if(command == 1001)
				login();
		}	
		
	}
	
	public void login() throws IOException, ClassNotFoundException{
		User u =null;
		String name = ois.readUTF();
		String pw = ois.readUTF();
		if(name.equals("xiaoming")&&pw.equals("123123"))
		u = new User("xiaoming","123123");
		oos.writeObject(u);
	}
	public static void main(String[] args) {
		try {
			new MyServer();
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
