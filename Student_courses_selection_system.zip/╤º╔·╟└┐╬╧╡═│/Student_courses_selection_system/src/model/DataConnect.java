package model;

import java.sql.*;

public class DataConnect {
   private static Statement stat;
   private static Connection con;
   private static PreparedStatement pstat;
   private static void init() throws ClassNotFoundException, SQLException{
	   Class.forName("com.mysql.jdbc.Driver");
	   String url="jdbc:mysql://localhost:3306/MySql?user=root&password=root";
	   con=DriverManager.getConnection(url);
	   stat=con.createStatement();

	   url="use qiangke";
	   stat.executeUpdate(url);
	   System.out.println("ok");
   }
   public static Statement getStat() throws ClassNotFoundException,SQLException{
	  if (stat==null)
		   init();
	  return stat;
	  }
   public static Connection getCon() throws ClassNotFoundException,SQLException{
		  if (con==null)
			   init();
		  return con;
		  }
   public static PreparedStatement getPStat(String sql) throws ClassNotFoundException,SQLException{
		  if (con==null)
			   init();
		  pstat=con.prepareStatement(sql);
		  return pstat;
	   }
   public static void main(String[] args){
	   try{
		  DataConnect.init();  
	   }catch(ClassNotFoundException e){
		  e.printStackTrace();
	   }catch(SQLException e){
		  e.printStackTrace(); 
	   }
   }
}
