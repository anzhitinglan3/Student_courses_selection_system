package model;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ModelFactory {
	private static Student stu;
	public static Student slogin(int sid,String spw) throws SQLException,ClassNotFoundException{
		Student stu=null;
		String sql="select * from student where sid="+sid+" and spw='"+spw+"'";
		ResultSet rs=DataConnect.getStat().executeQuery(sql);
		if(rs.next())
			stu=new Student(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5));
		return stu;
		/*   
		stu=new Student();
		stu=stu.slogin(sid, spw);
		return stu;
		*/
		}
   public static Teacher tlogin(int tid,String tpw) throws SQLException,ClassNotFoundException{
	   Teacher tea=null;
	   String sql="select * from teacher where tid="+tid+" and tpw='"+tpw+"'";
	   ResultSet rs=DataConnect.getStat().executeQuery(sql);
	   if(rs.next())
		   tea=new Teacher(rs.getInt(1),rs.getString(2),rs.getString(3));
	   return tea;
   }
   public static ArrayList<Course> getCourse() throws SQLException, ClassNotFoundException{
	   if(stu==null) stu = new Student();
	   return stu.getCourse();
   }
   public static ArrayList<Result> ViewAllResult(Student stu) throws SQLException, ClassNotFoundException {
	   return stu.ViewAllResult();
   }
   public static Result viewCourseResult(Student stu,int cid) throws SQLException, ClassNotFoundException {
	   return stu.viewCourseResult(cid);
	   }
   /*
   public static ArrayList<Course> sSearCou(Course cid) throws SQLException, ClassNotFoundException{
	return cid.sSearCour();
   }*/
public static ArrayList<Course> sSearCou(Course cid) {
	// TODO Auto-generated method stub
	return null;
}
}
