package model;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Course {

	private int cid;
	private int tid;
	private String cname;
	private String ctime;
	private String clocation;
	//private int credit;
	//private int max;

	public Course(int cid,int tid , String cname, String ctime,
			String clocation) {
		super();
		this.cid = cid;
		this.cname = cname;
		this.tid = tid;
		this.ctime = ctime;
		this.clocation = clocation;
		//this.credit = credit;
		//this.max = max;
	}

	public String getClocation() {
		return clocation;
	}
	public void setClocation(String clocation) {
		this.clocation = clocation;
	}
	
	public int getId() {
		return cid;
	}
	public void setId(int id) {
		this.cid = id;
	}
	public String getName() {
		return cname;
	}
	public void setName(String name) {
		this.cname = name;
	}
	public int getTid() {
		return tid;
	}
	public void setTid(int tid) {
		this.tid = tid;
	}
	public String getClasstime() {
		return ctime;
	}
	public void setClasstime(String classtime) {
		this.ctime = classtime;
	}
	/*
	public int getCredit() {
		return credit;
	}
	public void setCredit(int credit) {
		this.credit = credit;
	}
	public int getMax() {
		return max;
	}
	public void setMax(int max) {
		this.max = max;
	}*/

	public ArrayList<Course> getCourse(int cid) throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		ArrayList<Course> course=new ArrayList<Course>();
		String sql="select * from cid="+cid;
		ResultSet rs=DataConnect.getStat().executeQuery(sql);
		while(rs.next()){
			course.add(new Course(rs.getInt(1),rs.getInt(2),
					rs.getString(3),rs.getString(4),rs.getString(5)));
		}
		return course;
	}
}
