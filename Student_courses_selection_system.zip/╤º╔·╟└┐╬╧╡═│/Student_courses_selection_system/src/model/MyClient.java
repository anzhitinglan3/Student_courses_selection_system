package model;

import java.io.*;
import java.net.*;


public class MyClient {

	private ObjectOutputStream oos;
	private ObjectInputStream ois;
	public MyClient() throws UnknownHostException, IOException{
		String ip ="10.12.9.20";
		int port = 3081;
		Socket s = new Socket(ip,port);
		oos = new ObjectOutputStream(s.getOutputStream());
		ois = new ObjectInputStream(s.getInputStream());
		
	}
	
	public User login(String name,String pw) throws IOException, ClassNotFoundException{
		oos.writeInt(1001);
		oos.flush();
		oos.writeUTF(name);
		oos.flush();
		oos.writeUTF(pw);
		oos.flush();
		User u = (User) ois.readObject();
		return u;
	}
	
	
	
	
	public static void main(String[] args) {
		try {
			new MyClient();
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
