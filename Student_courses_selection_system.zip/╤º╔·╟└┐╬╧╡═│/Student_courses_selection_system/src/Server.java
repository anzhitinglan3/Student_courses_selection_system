import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.SQLException;
import java.util.Date;

import model.ModelFactory;
import model.Student;
import model.Teacher;

public class Server implements Protocal{
	private ObjectOutputStream oos;
	private ObjectInputStream ois;
	public Server() throws IOException, ClassNotFoundException,
	SQLException{
		ServerSocket ss=new ServerSocket(13081);
		int count=1;
		System.out.println("����������");
		while(true){
			Socket s=ss.accept();
			System.out.println("��"+count+"���û����ʷ�������"+
					s.getInetAddress()+new Date());
			count++;
			ois=new ObjectInputStream(s.getInputStream());
			oos=new ObjectOutputStream(s.getOutputStream());
			int command=ois.readInt();
			if(command == SLOGIN){
				slogin();
			}else if(command==TLOGIN){
				tlogin();
			}
		}
	}
	public void slogin() throws IOException, ClassNotFoundException,
	SQLException{
		int name=ois.readInt();
		String pw=ois.readUTF();
		ModelFactory lc=new ModelFactory();
		Student s=lc.slogin(name,pw);
		oos.writeObject(s);
		oos.flush();
	}
	public void tlogin() throws IOException, ClassNotFoundException,
	SQLException{
		int name=ois.readInt();
		String pw=ois.readUTF();
		ModelFactory lc=new ModelFactory();
		Teacher s=lc.tlogin(name,pw);
		oos.writeObject(s);
		oos.flush();
	}
	public static void main(String[] args){
		try {
			new Server();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
}
