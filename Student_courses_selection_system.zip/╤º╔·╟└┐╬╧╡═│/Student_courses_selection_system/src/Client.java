import java.io.*;
import java.net.*;

import model.Student;
import model.Teacher;

public class Client implements Protocal{

	private ObjectOutputStream oos;
	private ObjectInputStream ois;
	public Client() throws UnknownHostException, IOException{
		int port=13081;
		String ip="10.12.0.57";
		Socket s=new Socket(ip,port);
		oos=new ObjectOutputStream(s.getOutputStream());
		ois=new ObjectInputStream(s.getInputStream());
	}
	public Student slogin(int id,String pw) throws IOException,
	ClassNotFoundException{
		
		oos.writeInt(SLOGIN);
		oos.flush();
		oos.writeInt(id);
		oos.flush();
		oos.writeUTF(pw);
		oos.flush();
		Student s=(Student)ois.readObject();
		return s;
	}
	public Teacher tlogin(int id,String pw) throws IOException,
	ClassNotFoundException{
		
		oos.writeInt(TLOGIN);
		oos.flush();
		oos.writeInt(id);
		oos.flush();
		oos.writeUTF(pw);
		oos.flush();
		Teacher s=(Teacher)ois.readObject();
		return s;
	}
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub

//	}

}
